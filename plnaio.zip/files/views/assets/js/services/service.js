/*
 * Services
 */

var RESTService = new Appery.RestService({
    'url': '',
    'dataType': 'json',
    'type': 'get',
});

var crunchbase = new Appery.RestService({
    'url': 'http://api.crunchbase.com/v/1/search.js',
    'dataType': 'jsonp',
    'type': 'get',
});

var MongoLab = new Appery.RestService({
    'url': 'https://api.mongolab.com/api/1/databases/cashyup/collections/stocks?apiKey=b_6OqxduIanXrxocmvTsAXubns5iehpq',
    'dataType': 'json',
    'type': 'get',
});
stockchart = new Appery.getChartStock({});
GenericService = new Appery.GenericService({});