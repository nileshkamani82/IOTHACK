package poc;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLConnection;
import java.util.ArrayList;
import java.util.List;

import au.com.bytecode.opencsv.CSVReader;

public class Yahoo {
	private final String USER_AGENT = "Mozilla/5.0";
	private static final String _URL = "https://api.mongolab.com/api/1/databases/cashyup/collections/stocks?apiKey=b_6OqxduIanXrxocmvTsAXubns5iehpq";

	public static void main(String[] args) {
		
		while(true){
		URL url = null;
		try {
		url = new URL("http://finance.yahoo.com/d/quotes.csv?s=RHT+MSFT+PLT+DELL+IBM+INTC+JCP+CSCO+FB&f=ns");
		} catch (MalformedURLException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
		}

		URLConnection openConnection = null;
		try {
		openConnection = url.openConnection();
		} catch (IOException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
		}

		InputStream inputStream = null;
		try {
		inputStream = openConnection.getInputStream();
		} catch (IOException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
		}

		// BufferedInputStream bis = new BufferedInputStream(inputStream);

		CSVReader reader = new CSVReader(new InputStreamReader(inputStream), ',', '"', 0);
		List<String[]> myEntries = new ArrayList<String []>();
		try {
		myEntries = reader.readAll();
		} catch (IOException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
		}
int i=0;
		for(String[] stringArray : myEntries)
		{
			if(Math.random()*10>=5){
				mongolab(++i,stringArray);
			}
		}

		try {
		inputStream.close();
		} catch (IOException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
		}

		/*
		File file = new File("testYahoo.csv");
		try {
		file.createNewFile();
		} catch (IOException e2) {
		// TODO Auto-generated catch block
		e2.printStackTrace();
		}
		if(!file.exists())
		{
		System.out.println("File " + file + " could not be created");	
		}

		FileOutputStream fileOutputStream = null;
		try {
		fileOutputStream = new FileOutputStream(new File("testYahoo.csv"));
		} catch (FileNotFoundException e1) {
		// TODO Auto-generated catch block
		e1.printStackTrace();
		}

		byte[] byteArray = new byte[30];
		try {
		while(bis.read(byteArray) != -1)
		{
		System.out.println(byteArray);
		fileOutputStream.write(byteArray);
		}
		} catch (IOException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
		}
		finally
		{
		try {
		bis.close();
		inputStream.close();
		fileOutputStream.flush();
		fileOutputStream.close();

		} catch (IOException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
		}
		}
		*/
		try {
			Thread.sleep(30000);
			
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		}
	}
	
	
	
	public static void mongolab(int itr,String[] args) {
		System.out.println(args[0]+""+args[1]);
		try {
//			delete();
				URL url = new URL(_URL);
				HttpURLConnection conn = (HttpURLConnection) url.openConnection();
				conn.setDoOutput(true);
				conn.setRequestMethod("POST");
				conn.setRequestProperty("Content-Type", "application/json");

				String input = "{"+
						"\"_id\": \""+itr+"\","+
						"\"name\": \""+args[0]+"\",    \"yfcode\": \""+args[1]+"\"}";

				OutputStream os = conn.getOutputStream();
				os.write(input.getBytes());
				os.flush();

				if (conn.getResponseCode() != HttpURLConnection.HTTP_CREATED) {
//					throw new RuntimeException("Failed : HTTP error code : "
//							+ conn.getResponseCode());
				}

				BufferedReader br = new BufferedReader(new InputStreamReader(
						(conn.getInputStream())));

				String output;
				System.out.println("Output from Server .... \n");
				while ((output = br.readLine()) != null) {
					System.out.println(output);
				}

				conn.disconnect();

		} catch (MalformedURLException e) {

			e.printStackTrace();

		} catch (IOException e) {

			e.printStackTrace();

		}
	}

}
